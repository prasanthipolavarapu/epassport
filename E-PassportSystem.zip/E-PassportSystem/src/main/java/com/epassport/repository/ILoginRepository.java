package com.epassport.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.epassport.entity.Login;

@Repository
public interface ILoginRepository extends JpaRepository<Login, Integer> {
	
	Login findByEmail(String email);

}