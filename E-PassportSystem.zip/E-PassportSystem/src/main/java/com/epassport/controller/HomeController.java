package com.epassport.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {

	@RequestMapping("/")
	public String home() {
		return "index";
	}
	@RequestMapping("/login")
	public String home2() {
		return "index";
	}
	 @GetMapping("/contactus")

	 public String AddPassport()

	 {

	 return "contactus";

	 }
	 @RequestMapping("/trackingapply")
		public String home1() {
			return "trackingapply";
		}
	 
}
