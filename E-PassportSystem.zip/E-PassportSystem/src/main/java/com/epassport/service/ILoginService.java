package com.epassport.service;

import com.epassport.entity.Login;

public interface ILoginService {
	
	Login validateLogin(Login login);

}