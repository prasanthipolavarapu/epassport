package com.epassport.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.epassport.entity.Citizen;
import com.epassport.repository.ICitizenRepository;


@Service
public class EmployeeServiceImpl implements IEmployeeService {
	
	@Autowired
	ICitizenRepository empRepo;

	// ADD Employee
	@Override
	public Citizen saveOrUpdateEmployee(Citizen emp) {
		return empRepo.save(emp);
	}

	// DELETE
	@Override
	public void deleteEmployeeById(int empId) {
		empRepo.deleteById(empId);
	}

	// GET - ByID
	@Override
	public Citizen getEmpById(int empId) {
		return empRepo.findById(empId).get();
	}
	
	// GET - ByName
	@Override
	public Citizen getEmpByName(String empName) {
		return empRepo.findByEmpName(empName);
	}

	// GET - All Employees
	@Override
	public List<Citizen> getAllEmployees() {
		return empRepo.findAll();
	}

	

	
}