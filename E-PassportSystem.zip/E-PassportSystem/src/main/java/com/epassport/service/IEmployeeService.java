package com.epassport.service;

import java.util.List;

import com.epassport.entity.Citizen;

public interface IEmployeeService {
	
	Citizen saveOrUpdateEmployee(Citizen emp);
	void deleteEmployeeById(int empId);
	Citizen getEmpById(int empId);
	Citizen getEmpByName(String empName);
	List<Citizen> getAllEmployees();

}
