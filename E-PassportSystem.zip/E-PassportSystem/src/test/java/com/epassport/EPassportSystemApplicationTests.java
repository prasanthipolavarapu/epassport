package com.epassport;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EPassportSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
